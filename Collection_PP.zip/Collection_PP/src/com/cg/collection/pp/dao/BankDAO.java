/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.dao;

import com.cg.collection.pp.bean.Customer;
import java.util.HashMap;

public class BankDAO {

    HashMap<Long,Customer> hashMap = new HashMap<Long, Customer>();
    
    public long createAccount(Customer customer) {
        hashMap.put(customer.getAccountNo(),customer);
        return customer.getAccountNo();
      }

    public HashMap<Long, Customer> getHashMap() {
        return hashMap;
    }

    public int depositeMoney(long accountNumber, int totalbal,String transaction) {
    hashMap.get(accountNumber).setBalance(totalbal);
    hashMap.get(accountNumber).setTrans(transaction);
    return hashMap.get(accountNumber).getBalance();    
    }

    public int withdrawMoney(long accountNumbr, int totalbal,String transaction) {
    hashMap.get(accountNumbr).setBalance(totalbal);
    hashMap.get(accountNumbr).setTrans(transaction);
    return hashMap.get(accountNumbr).getBalance();    
    }

    public void fundTransfer(long fromaccountNo, long toaccountNo, int totalWithdraw, 
            int totalDeposite, String transaction1, String transaction2) {
    hashMap.get(fromaccountNo).setBalance(totalWithdraw);
    hashMap.get(toaccountNo).setBalance(totalDeposite);
    hashMap.get(fromaccountNo).setTrans(transaction1);
    hashMap.get(toaccountNo).setTrans(transaction2);
    }

    public String printTransaction(long acountNo) {
    return hashMap.get(acountNo).getTrans();
    }
    
}
