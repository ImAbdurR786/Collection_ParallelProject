package com.cg.collection.pp.service;

import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.dao.BankDAO;
import java.util.regex.Pattern;

public class BankService {
    BankDAO bankDao = new BankDAO();
    
    public long createAccount(Customer customer) {
      return bankDao.createAccount(customer);
    }

    public int showBalance(long acntNo, int pinNo) {
    if(bankDao.getHashMap().containsKey(acntNo)){
    if(bankDao.getHashMap().get(acntNo).getPin()==pinNo){
    return bankDao.getHashMap().get(acntNo).getBalance();
    }else return -1;
    }else return 0;
    }

    public int  depositeMoney(long accountNumber, int amountDeposite, String trans) {
    String transaction = trans+ "\n" + bankDao.getHashMap().get(accountNumber).getTrans();
    int totalbal = bankDao.getHashMap().get(accountNumber).getBalance() + amountDeposite;
    return bankDao.depositeMoney(accountNumber,totalbal,transaction);
    }

    public int withdrawMoney(long accountNumbr, int amountWithdraw,String trans) {
        String transaction = trans+ "\n" + bankDao.getHashMap().get(accountNumbr).getTrans();
        if(bankDao.getHashMap().get(accountNumbr).getBalance()>amountWithdraw){
        int totalbal = bankDao.getHashMap().get(accountNumbr).getBalance() - amountWithdraw;
            return bankDao.withdrawMoney(accountNumbr,totalbal,transaction);
        }else
            return -1;
    }

    public int fundTransfer(long fromaccountNo, long toaccountNo, int moneyTransfer,String trans1, String trans2) {
      String transaction1 = trans1+ "\n" + bankDao.getHashMap().get(fromaccountNo).getTrans(); 
      String transaction2 = trans2+ "\n" + bankDao.getHashMap().get(toaccountNo).getTrans(); 
      
     if(bankDao.getHashMap().get(fromaccountNo).getBalance()>moneyTransfer){
     int totalWithdraw = bankDao.getHashMap().get(fromaccountNo).getBalance() - moneyTransfer;
     int totalDeposite = bankDao.getHashMap().get(toaccountNo).getBalance() + moneyTransfer;
     bankDao.fundTransfer(fromaccountNo,toaccountNo,totalWithdraw,totalDeposite,transaction1,transaction2);
     return 1;}
     else return -1;
    }

    public boolean isNameValid(String name){
       if(name.length()>4){
            if(Pattern.matches("([A-Z])*([a-z])*", name)){
            return true;
            }else{
            return false;
            }
          }
      else
       return false;
    }
    
    public boolean isAccountValid(long toaccountNo) {
    if(bankDao.getHashMap().containsKey(toaccountNo)){
    return true;}
    else
    return false;    
    }

    public String printTransaction(long acountNo) {
    return bankDao.printTransaction(acountNo);
    }

    public boolean isValidNumber(String number) {
    return true;
    }
}
