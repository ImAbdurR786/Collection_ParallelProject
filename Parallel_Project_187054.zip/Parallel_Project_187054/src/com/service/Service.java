package com.service;

import com.bean.Customer;
import com.dao.DAO;
import java.util.HashMap;

public class Service {
    DAO d = new DAO();
 public void create(Customer c){
   d.create(c);
 }    

    public void trans(String string, long accountNo) {
       d.trans(string, accountNo);
    }

    public HashMap<Long,Customer> getHash() {
        return d.getHash();
    }
 
    public Customer show(long showaccount){
         if(d.getHash().containsKey(showaccount)) {
		return d.getHash().get(showaccount);
			}
			else
		return null;
}

    public void deposite(long accountdeposit, int deposite) {
         d.getHash().get(accountdeposit).setDeposite(deposite);
        int bal = d.getHash().get(accountdeposit).getDeposite() + d.getHash().get(accountdeposit).getBalance();
        d.getHash().get(accountdeposit).setBalance(bal);
}

    public void withdraw(long accountwithdraw, int withdraw) {
     d.getHash().get(accountwithdraw).setWithdraw(withdraw);
		int balance = d.getHash().get(accountwithdraw).getBalance() - d.getHash().get(accountwithdraw).getWithdraw();
		if(balance>0) {d.getHash().get(accountwithdraw).setBalance(balance);
                }else
			System.out.println("Insufficient Balance");
			}

    public int fundTransfer(Long from, Long to, int money) {
        Customer cFrom = (Customer) d.getHash().get(from);
		int fBalance = cFrom.getBalance();
		if(money<fBalance) {
			Customer cTo = (Customer) d.getHash().get(to);
			int totalMoney = cTo.getBalance() + money;
			 cTo.setBalance(totalMoney);
			 d.trans("Deposite"+money+"from account no."+from,to); 
			
			 int totalMony = fBalance - money;
			 cFrom.setBalance(totalMony);
			 d.trans("Transfer"+money+"to account no."+to,from); 
								
			return 1;
			}
		else 
			return -1;
    }

    public HashMap<String, Long> getTrans() {
   return d.getTrans();
    }
    
     public String get(HashMap<String,Long>hm,Long acc) {
		String s = "";
		
		for(String key : hm.keySet()) {
			if(hm.get(key).equals(acc)) {
				s += key + " ; ";
				}
			}
		return s;
	}
    
    }



