package com.ui;

import com.bean.Customer;
import com.exception.UserDefineException;
import com.service.Service;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Menu {

public static void main(String args[]){
                                                                                          
            //Accepting the input from the User.
		Scanner sc = new Scanner(System.in);
                Customer c;
                long accountNo = 0;
                Service s = new Service();
		do {
                    //Printing the menu bar.
		System.out.println("***************************************************************************");
		System.out.println("1. Create Account \n 2. Show Balance \n 3. Deposite "
				+ "\n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transcaction \n 7. Exit");
		System.out.println("***************************************************************************");
                System.out.println("Choose any option : ");
		int n = sc.nextInt();
		
		// According to input from user the method is called using switch case.
		switch(n) {

         case 1:
		double a = Math.random()%100;            // Creating a random number
		accountNo =(long)(a*1234567898);    // Mutliplying with a dummy no. to get dummy account no.
                String name;
		do{System.out.println("Enter the Name");
		name = sc.next();
                }while(!Pattern.matches("([A-Z])*([a-z])*", name));
	
		System.out.println("Enter the Number");
		String number = sc.next();
		try{
		Long.parseLong(number);                                                                                                             
		if(number.length() == 10) {
		System.out.println("Enter the IDno.");
		int Idno = sc.nextInt();
		System.out.println("Enter the Balance to be deposit.");
		int deposit = sc.nextInt();
		c = new Customer(name,number,Idno,deposit); 
		c.setAccountNo(accountNo);
	
		c.setBalance(deposit);
	
		s.trans("Initially "+deposit,accountNo);
		s.create(c);
		System.out.println("Your account is Created Successfully");
		System.out.println("Account number is :" + c.getAccountNo());
		
		}
		else
		try{
                    throw new UserDefineException("Number should be of 10 digits");
                }catch(Exception exc){
                }
                    }catch(Exception e ) {
                        System.out.println("Number should contain only digits");}
		
            break;
         case 2:
             System.out.println("Enter the Account no.");
			Long showaccount = sc.nextLong();
			
                       Customer customer =  s.show(showaccount);
                       if(customer==null){
                           System.out.println("No such AccountNo Exist");
                       }else{
                           System.out.println(customer);
                       }
                        break;
         case 3:
             
        System.out.println("Enter the account number");
	long accountdeposit = sc.nextLong();
        if(s.getHash().containsKey(accountdeposit)){
	System.out.println("Enter the amount to be deposite");	
	int deposite = sc.nextInt();
        s.deposite(accountdeposit,deposite);
	System.out.println("Successfully Deposited");
	s.trans("Deposite "+deposite,accountNo);
	
	}else
		System.out.println("No such Account Number");
        break;
                
         case 4:
             
             System.out.println("Enter the account number");
		long accountwithdraw = sc.nextLong();
		if(s.getHash().containsKey(accountwithdraw)){
		System.out.println("Enter the amount to be withdraw");	
		int withdraw = sc.nextInt();
		s.withdraw(accountwithdraw,withdraw);
               
		s.trans("Withdraw "+withdraw,accountNo);
		
		System.out.println("Successfully Withdraw");
                }else
			System.out.println("No such Account Number");
		break;
                
         case 5:
             Long to;
                System.out.println("Enter your account number.");
		Long from = sc.nextLong();
                
		if(s.getHash().containsKey(from)) {
		do{System.out.println("Enter account number to transfer the money.");
		to = sc.nextLong();
                }while(!s.getHash().containsKey(to));
                
                if(from.equals(to)){
                    System.out.println("Both account number must be different");
                }else{
		if(s.getHash().containsKey(to)) {
                System.out.println("Enter the money to be transfer");
		int money = sc.nextInt();
		if(s.fundTransfer(from,to,money) == 1){
                 System.out.println("Successfully Transfer");}
                else{
                    System.out.println("Insufficient Money");
                }
		}else 
			System.out.println("Invalid Account Number");
		}}else 
			System.out.println("Invalid Account Number");
     break;
     
         case 6:
                System.out.println("Enter the Account Number");
		long transAcc = sc.nextLong();
		
		if(s.getTrans().containsValue(transAcc))
		{
			System.out.println(s.get(s.getTrans(),transAcc));
			
		}
		else {
			System.out.println("No such Account");
		}
             
             break;
             
		case 7: System.exit(0);
		default :
			System.out.println("Enter the valid choice");
		
		}}while(true);
	} 
}    